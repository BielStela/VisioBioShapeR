
# Set of functions used in library 'VisioBioshapeR'
# Biel Stela & Toni Monleón - 21-4-2016
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'


#############################################################################################
#############################################################################################
#                    VisioBioshapeR
#     by Toni Monleon & Biel Stela. version 0.1 (26/2/2016)
#############################################################################################
#############################################################################################


#todo esto para el help:


#this script contains the functions for:

# 1-read a binary black image
# 2-extract the coordinates of the binary black image
# 3-extract the 4 coefficient (A,B,C and D)  of the elliptic fourier harmonics
# 4-analyze using PCA of the coeffcient of the 4 coefficient (A,B,C and D)  of the elliptic fourier harmonics
# 5-represent in a graph the image using the harmonics of the elliptic fourier harmonics
# 6-export coefficients and PCA analysis.


##############(R libraries)#######################################

library(rtiff)        #per llegir .tiff formats
library(cluster)      #per calcular els medoids - centre geometric
library(raster)
library(rgdal)
library(reshape2)
library(data.table)
library(Momocs)

######################################################


#               DESCRIPTION


#######################################################################################
# VisioBioshapeR: library to perform an authomatic elliptic  analysis of a binary file .tiff
# (Funcio per fer un analisi de fourier  d' una imatge a partir d un fitxer de coordenades)
#######################################################################################
# 26.02.2016

# library VisioBioshapeR:
#
#1.Carregar llibreries
#2.cargar fichero de texto del directorio de training
#3.Por cada fichero:
# 3.1.Semi-automàtic outline selector (Conte)
# 3.2.Hacer fourier
#   3.2.1.Elliptic fourier function
#   3.2.2 Normalize elliptic fourier
# 3.3.Hacer PCA (coeficientes normalizados)
# 3.4. almacenar valores del PCA

# 3.5. representar todos los valores en un punto y clasificar
#



################################################################################
#   FUNCTIONS AND ITS DESCRIPTION
#################################################################################


###################### NOU ########################################################
### Carregam l'imatge tipo template i extreim el contorn semi-automàticament
### amb la funció Conte extreta de 'Morphometrics with R' i no depenem
### d'altres programes com ImageJ :)
### Un cop inicialitzat el "locator" fer click a la part esquerra del plot per
### definir un punt de partida del contorn
######################################################



##########################################################################
#                       function Conte
##########################################################################

#####################################################
#funció CONTE per extreure coordenades de l'outline
#####################################################
Conte<-function(x, imagematrix)
{I<-imagematrix
x<-rev(x)
x[1]<-dim(I)[1]-x[1]
traceback()
while (abs(I[x[1],x[2]]-I[x[1],(x[2]-1)])<0.1){x[2]<-x[2]-1}
  a<-1
  M<-matrix(c(0,-1,-1,-1,0,1,1,1,1,1,0,-1,-1,-1,0,1),2,8,byrow=T)
  M<-cbind(M[,8],M,M[,1])
  X<-0; Y<-0;
  x1<-x[1]; x2<-x[2]
  SS<-NA; S<-6
while ((any(c(X[a],Y[a])!=c(x1,x2) ) | length(X)<3))
  {if (abs(I[x[1]+M[1,S+1],x[2]+M[2,S+1]]-I[x[1],x[2]])<0.1)
  {a<-a+1;X[a]<-x[1];Y[a]<-x[2];x<-x+M[,S+1]
  SS[a]<-S+1; S<-(S+7)%%8}
else if (abs(I[x[1]+M[1,S+2],x[2]+M[2,S+2]]-I[x[1],x[2]])<0.1)
  {a<-a+1;X[a]<-x[1];Y[a]<-x[2];x<-x+M[,S+2]
  SS[a]<-S+2; S<-(S+7)%%8}
else if (abs(I[x[1]+M[1,(S+3)],x[2]+M[2,(S+3)]]-I[x[1],x[2]])<0.1)
  {a<-a+1;X[a]<-x[1];Y[a]<-x[2];x<-x+M[,(S+3)]
  SS[a]<-S+3; S<-(S+7)%%8}
else S<-(S+1)%%8}
list(X=(Y[-1]), Y=((dim(I)[1]-X))[-1])


}

### OJO ######
# La funció "conte" ens genera una llista de dos objectes amb les coordenades de
#   CADA UN DELS PIXELS que formen l'outline.
# La funció "efourier" no pot funcionar a tan alta resolució de coordenades i per tant
#   s'ha de sotmetre la matriu de coordenades a una reducció de resolució per tal que
#   "efourier" pugui fer bé la seva feina
##############





##########################################################################
#                       function efourier
##########################################################################

######################################################
### Funcio ellitic fourier per convertir un cortorn en
### coeficients de fourier per a l'n-èssim harmònic (n)
######################################################

efourier<-function(M,n=dim(M)[1]/2) #definim el nombre d'armonics com la meitat dels punts mostreig
{p<-dim(M)[1]
Dx<-M[,1]-M[c(p,(1:p-1)),1]
Dy<-M[,2]-M[c(p,(1:p-1)),2]
Dt<-sqrt(Dx^2+Dy^2)
t1<-cumsum(Dt)
t1m1<-c(0, t1[-p])
T<-sum(Dt)
an<-bn<-cn<-dn<-numeric(n)
for (i in 1:n){
  an[i]<- (T/(2*pi^2*i^2))*sum((Dx/Dt)*(cos(2*i*pi*t1/T)-cos(2*pi*i*t1m1/T)))
  bn[i]<- (T/(2*pi^2*i^2))*sum((Dx/Dt)*(sin(2*i*pi*t1/T)-sin(2*pi*i*t1m1/T)))
  cn[i]<- (T/(2*pi^2*i^2))*sum((Dy/Dt)*(cos(2*i*pi*t1/T)-cos(2*pi*i*t1m1/T)))
  dn[i]<- (T/(2*pi^2*i^2))*sum((Dy/Dt)*(sin(2*i*pi*t1/T)-sin(2*pi*i*t1m1/T)))}
ao<-2*sum(M[,1]*Dt/T)
co<-2*sum(M[,2]*Dt/T)
list(ao=ao,co=co,an=an,bn=bn,cn=cn,dn=dn)}






##########################################################################
#                       function iefourier
##########################################################################
#########################################################################
### Funció inversa per convertir els coeficients cap contorn
###########################################################################

iefourier<-function(an,bn,cn,dn,k,n,ao=0,co=0)
{theta<-seq(0,2*pi, length=n+1)[-(n+1)]
harmx <- matrix (NA, k, n)
harmy <- matrix (NA, k, n)
for (i in 1:k){
  harmx[i,]<-an[i]*cos(i*theta)+bn[i]*sin(i*theta)
  harmy[i,]<-cn[i]*cos(i*theta)+dn[i]*sin(i*theta)}
x<-(ao/2) + apply(harmx, 2, sum)
y<-(co/2) + apply(harmy, 2, sum)
list(x=x, y=y)}


##########################################################################
#                       function NEFnormalization
##########################################################################

# NORMALITZAR ELS COEFICIENTS DE FOURIER :
#
# "Els coeficients del primer harmonic defineixen l'ellipse que més s'adapta al contorn.
# Usam el primer harmònic per normalitzar les dades i passen a ser invariants al
# tamany, rotació, i punt d'inici del contorn. Així convertim els coeficients "an, bn, ..."
# als coeficients normalitzats "An,Bn..."
# Si no s'aplica la normalització els coeficients també contenen informació que no depèn
# tan sols de la forma"
#
# Bibliography: Morphometric with R
#
#####################################################

NEFnormalization<-function(M, n=dim(M)[1]/2,start=F)
{ef<-efourier(M,n)
A1<-ef$an[1]; B1<-ef$bn[1]
C1<-ef$cn[1]; D1<-ef$dn[1]
theta<-0.5*atan(2*(A1*B1+C1*D1)/(A1^2+C1^2-B1^2-D1^2))
Aa<-A1*cos(theta)+B1*sin(theta)
Cc<-C1*cos(theta)+D1*sin(theta)
scale<-sqrt(Aa^2+Cc^2)
psi<-atan(Cc/Aa)%%pi
size<-(1/scale)
rotation<-matrix(c(cos(psi),-sin(psi),sin(psi),cos(psi)),2,2)
A<-B<-C<-D<-numeric(n)
if (start){theta<-0}
for (i in 1:n){
  mat<-size*rotation%*%matrix(c(ef$an[i],ef$cn[i],ef$bn[i],ef$dn[i]),2,2)%*%matrix(c(cos(i*theta),sin(i*theta),-sin(i*theta),cos(i*theta)),2,2)
  A[i]<-mat[1,1]
  B[i]<-mat[1,2]
  C[i]<-mat[2,1]
  D[i]<-mat[2,2]}
list(A=A,B=B,C=C,D=D,size=scale,theta=theta,psi=psi,ao=ef$ao,co=ef$co)}




##########################################################################
#                       function e.fourier.graph
##########################################################################

#################################################################################################
# Graph of 9 harmonics using efourier
##################################################################################################
#' e.fourier.graph
#'
#' @param M is a matrix with X,Y coordinates of the image
#' @param harmonic number of harmonics to be represented
#' @param coef if the coefficients of the harmonics in EFD are requiered
#' @param normalized Normatized = T, non normalized = F
#' @return a graph with the reconstruction of the image using the EFD analysis
#' @export
e.fourier.graph<-function(M, n.harmonics=9, coef=FALSE, normalized=FALSE) { #definim el nombre d'armonics com la meitat dels punts mostreig

  #attach(mtcars)
  #plot(wt, mpg, main="Scatterplot Example",
  #     xlab="Car Weight ", ylab="Miles Per Gallon ", pch=19)
  #M <- data.frame(wt, mpg)

  #si quiero que me displaye los coeficientes de los armónicos de Fourier
  if (normalized ==TRUE) {
    ef1 <-NEFnormalization(M)
    #unificar los coeficientes que se leen:
    ef1$an<-ef1$A
    ef1$bn<-ef1$B
    ef1$cn<-ef1$C
    ef1$dn<-ef1$D
    #M NORMALITZADA
  }
  if (normalized ==FALSE) {
    ef1 <- efourier(M) #M NO NORMALITZADA
  }


#PLOT
layout(matrix((1:9),3,3))
par(mar=c(2,2,2,2))

#display del grafico de reconstrucción de la imagen a partir de los harmonicos normalizados o no
for (i in 1:n.harmonics)
{
  #i<-5
  ief1<-iefourier(ef1$an,ef1$bn,ef1$cn,ef1$dn,i,64,ef1$ao,ef1$co)
  plot(M,type="l",asp=1,frame=F,main=paste("Harmonics 0 to",i),col="red")
  polygon(M,col="grey",border=NA)
  lines(ief1$x,ief1$y,type="l")
}

#si quiero que me displaye los coeficientes de los armónicos de Fourier
if (coef ==TRUE) {
  print("Coefficient A")
  return(ef1$an[1:n.harmonics])
  print("Coefficient B")
  return(ef1$bn[1:n.harmonics])
  print("Coefficient C")
  return(ef1$cn[1:n.harmonics])
  print("Coefficient D")
  return(ef1$dn[1:n.harmonics])
}


}

##########################################################################
#                       function coordtiff
##########################################################################

#################################################################################################
# crida d' una imagtge de tipus .tif
# extract a X, Y coordinates from tif file, automatically
# if there are more than one image  in the tiff file, extract the coordinate of same of them randomly
##################################################################################################

#' coordtiff
#'
#' @param file if a tiff file to be readed (binary file format)
#' @param harmonic if harmonic=true graph representation of 9 firs harmonics
#' @return The Coordinates X,Y of the image contorn
#' @export
coordtiff<-function(file, harmonic = TRUE, normalized=FALSE) #definim el nombre d'armonics com la meitat dels punts mostreig
{
    #file<-"dragonfly.tif"
    par(mfrow=c(1,1)) #inicialize graphical
    shape <- readTiff(file)
    y <- as(shape, "pixmapGrey")  #trasformam la imatge a "pixmapGrey"
    plot(y, new=F)
    len1 <- y@size[1] #n files
    len2 <- y@size[2] #n cols
    ran1 <- as.vector(floor(runif(1, 1, len1))) #coordenada X random
    ran2 <- as.vector(floor(runif(1, 1, len2)))  # coordenada Y random
    ##############
    # A U T O M A T I T Z A C I Ó     C O N T E
    ##############
    Rc<-try(Conte(c(round(ran1),round(ran2)),y@grey))
    while(class(Rc) == "try-error") {

      ran1 <- as.vector(floor(runif(1, 1, len1))) #coordenada X
      ran2 <- as.vector(floor(runif(1, 1, len2)))  # coordenada Y
      Rc<-try(Conte(c(round(ran1),round(ran2)),y@grey))
    }

    #start<-locator(1)     #LOCATOR fer clic al plot per definir el punt de partida del outline
    #Rc<-Conte(c(round(start$x),round(start$y)),y@grey)  #Cream les coordenades XY a la variable Rc
    lines(Rc$X, Rc$Y, lwd=4, col='red')
    arrows(0,Rc$Y[1],Rc$X[1],Rc$Y[1],length=0.1)  #plot de la linea i del punt de partida


    ########################################################
    # PLOT evolució harmònics i redimensionar coordenades
    ########################################################

    #convertim l'objecte de la funció "Conte" a un matriu i la passam a Data Frame
    M<-sapply(Rc, unlist)
    M<-data.frame(M)

    #REDUCCIÓ DE RESOLUCIÓ de la matriu de coordenades a la meitat
    # llevant una de cada dues entrades per evitar
    # problemes amb la funció "efourier"
    dim<-dim(M)
    M <- M[-c(seq(1,dim[1],by=2)), ] #COORDENADES DE LA IMATGE

    #si quiero que me displaye los coeficientes de los armónicos de Fourier
    if (normalized ==TRUE) {
      ef1 <-NEFnormalization(M)
      #unificar los coeficientes que se leen:
      ef1$an<-ef1$A
      ef1$bn<-ef1$B
      ef1$cn<-ef1$C
      ef1$dn<-ef1$D
      #M NORMALITZADA
    }
    if (normalized ==FALSE) {
      ef1 <- efourier(M) #M NO NORMALITZADA
    }

    #PLOT
    layout(matrix((1:9),3,3))

    #if harmonic representation is true
    if (harmonic ==TRUE) {
      par(mar=c(2,2,2,2))
      for (i in 1:9)
      {ief1<-iefourier(ef1$an,ef1$bn,ef1$cn,ef1$dn,i,64,ef1$ao,ef1$co)
      plot(M,type="l",asp=1,frame=F,main=paste("Harmonics 0 to",i),col="red")
      polygon(M,col="grey",border=NA)
      lines(ief1$x,ief1$y,type="l")}
      #delete graphical options
      par(mfrow=c(1,1))
    }



    #returm coordinate matrix M
    return(M)
    list(M = M)
}
#######################################################
#M: ES LA MATRIU QUE CONTE LES COORDENADES: X, Y (INPUT)
# M es un data frame que entrega la funcio coordtiff
#####################################################


coordtiff.NO.AUTOMATICA<-function(file, harmonic = TRUE) #definim el nombre d'armonics com la meitat dels punts mostreig
{
  shape <- readTiff(file)
  y <- as(shape, "pixmapGrey")                    #trasformam la imatge a "pixmapGrey"
  plot(y)
  start<-locator(1)     #LOCATOR fer clic al plot per definir el punt de partida del outline
  Rc<-Conte(c(round(start$x),round(start$y)),y@grey)  #Cream les coordenades XY a la variable Rc
  lines(Rc$X, Rc$Y, lwd=4, col='red')
  arrows(0,Rc$Y[1],Rc$X[1],Rc$Y[1],length=0.1)  #plot de la linea i del punt de partida


  ########################################################
  # PLOT evolució harmònics i redimensionar coordenades
  ########################################################

  #convertim l'objecte de la funció "Conte" a un matriu i la passam a Data Frame
  M<-sapply(Rc, unlist)
  M<-data.frame(M)

  #REDUCCIÓ DE RESOLUCIÓ de la matriu de coordenades a la meitat
  # llevant una de cada dues entrades per evitar
  # problemes amb la funció "efourier"
  dim<-dim(M)
  M <- M[-c(seq(1,dim[1],by=2)), ] #COORDENADES DE LA IMATGE
  ef1 <- efourier(M)
  NEFnormalization(M) #M NORMALITZADA
  #PLOT
  layout(matrix((1:9),3,3))
  par(mar=c(2,2,2,2))


  #if harmonic representation is true
  if (harmonic ==TRUE) {
    par(mar=c(2,2,2,2))
    for (i in 1:9)
    {ief1<-iefourier(ef1$an,ef1$bn,ef1$cn,ef1$dn,i,64,ef1$ao,ef1$co)
    plot(M,type="l",asp=1,frame=F,main=paste("Harmonics 0 to",i),col="red")
    polygon(M,col="grey",border=NA)
    lines(ief1$x,ief1$y,type="l")}
    #delete graphical options
    par(mfrow=c(1,1))
  }


  return(M)
  list(M = M)
}


#########################################################################################
#                        function automatic.PCAfourier.analysis
#########################################################################################

#####################################################
#funcio per fer un analisi de fourier d' una imatge a partir d un fitxer de coordenades

# Funcion AutomaticImageFourier
### Funcio ellitic fourier per convertir un cortorn en
### coeficients de fourier per a l'n-èssim harmònic (n)
# 1.Carrega matriu M (se puede obtener a partir de imagen tif con coordtiff)
# o un fichero de coordenadas X, Y
# 2.Por cada fichero o matriz M:
#  2.1.Hacer elliptic fourier, obtener coeficientes A, B, C y D para todos los harmonicos
#  2.2.Hacer PCA de los coeficientes de los harmonicos A, B, C y D
#  2.3. almacenar valores del PCA


######################################################


#' automatic.PCAfourier.analysis
#'
#' @param file if a tiff file to be readed (binary file format)
#' @param M if a matrix of X,Y coordinates
#' @param id.num sample ID
#' @param nom.label sample label
#' @param tipus.input file or matrix that contains the X,Y coordinates
#' @param normalized Normatized = T, non normalized = F
#' @return Vector of results: Columns 3-10: coeficients of PCA of all elliptic forurier coefficients;  columns 11-18: coeficients of PCA of a selected (nharmonics) elliptic forurier coefficients; columns 19-20: a0 and c0 geometric center of image; Column 21: euclidean maximum distance between coordinates X,Y
#' @export
#'
#cargar la FUNCIoN:
#PARAMETRES D' ENTRADA DE LA FUNCIo:
#file: FICHER D' ENTRADA IMATGE .TIFF, M: MATRIU DE COORDENADES, id.num, nom.label, tipus.input
#automatic.PCAfourier.analysis(file="", M=M, id.num=1, nom.label="d1", tipus.input=2,normalized = 1 )
#file <- "libelula.tif"
#automatic.PCAfourier.analysis(file="", M=M, id.num=1, "d1", tipus.input=2,normalized = F)
#file=""; M=M; id.num=1; nom.label="d1"; tipus.input=2;normalized = 0
#write.table(M, file="mymatrix.txt", row.names=F, col.names=T)
#leer de fichero de coordenadas
#automatic.PCAfourier.analysis(file="mymatrix.txt", , 1, "dragonfly", 1, 1, num.harmonic = 7)

automatic.PCAfourier.analysis<-function(file, M, id.num, nom.label, tipus.input=2, normalized = FALSE, num.harmonic = 15) #definim el nombre d'armonics com la meitat dels punts mostreig
{
  Fourier.matrix.results <- matrix (NA, 1, 21)
  #M=Gomphonema
  #si es fitxer o matriu triar input:
  'file es un fichero X,Y'
  if (tipus.input ==1) {
    #si input es matriu M
    M.coord <-read.csv(file, sep="")
    names(M.coord) <- c("X", "Y")
    #M.coord <-read.delim(file)
  'las coordenadas procedes de una matriz M, que contine las coordenadas X,Y capturadas anteriormente'
  }else
    #si input es matriu:
    M.coord <-M

  #dependiendo si se normalizan los datos de la matriz M o no:
  if (normalized ==T) {
    ef1<-NEFnormalization(M.coord) #NORMALITZACIO DELS COEFICIENTS OBTINGUTS A EFOURIER
    matriz.pca <- data.frame(ef1$A,ef1$B,ef1$C,ef1$D) #NORMALITZACIO DELS COEFICIENTS OBTINGUTS A EFOURIER
    #guardar los harmonicos, la fila 10:
    har.a <- ef1$A[num.harmonic]
    har.b <- ef1$B[num.harmonic]
    har.c <- ef1$C[num.harmonic]
    har.d <- ef1$D[num.harmonic]
  }

  if (normalized ==F) {
    ef1<-M.coord # NO NORMALITZACIO DELS COEFICIENTS OBTINGUTS A EFOURIER
    ef1<-efourier(M.coord) #SENSE NORMALITZACIO DELS COEFICIENTS OBTINGUTS A EFOURIER
    matriz.pca <- data.frame(ef1$an,ef1$bn,ef1$cn,ef1$dn) #SENSE NORMALITZACIO DELS COEFICIENTS OBTINGUTS A EFOURIER
    #guardar los harmonicos, la fila 10:
    har.a <- ef1$an[num.harmonic]
    har.b <- ef1$bn[num.harmonic]
    har.c <- ef1$cn[num.harmonic]
    har.d <- ef1$dn[num.harmonic]


    #analisis de eliptic fourier del contorno:
   #layout(matrix((1:18),3,3))
   #par(mfrow=c(5,4))
  }


  #dibujar las graficas de contorno con el fourier
  #for (i in 1:18)
  #{ief1<-iefourier(ef1$an,ef1$bn,ef1$cn,ef1$dn,i,64,ef1$ao,ef1$co)
  #plot(M,type="l",asp=1,frame=F,main=paste("Harmonics 0 to",i),col="blue")
  #polygon(M,col="grey",border=T)
  #lines(ief1$x,ief1$y,type="l")
  #}

  #pca del analisis de fourier
  #dependiendo si se normalizan los datos de la matriz M o no:

  #analisis de componentes principales: por descomposicion espectal
  pca <- prcomp(matriz.pca)                 # do a PCA for all coefficients
  pca.hasta.harmonico.i <-prcomp(matriz.pca[1:num.harmonic,]) #Select a number of harmonics 1: num.harmonic
  #summary(pca)
  #screeplot(pca, type="lines")
  pca$rotation[,1]
  pca$rotation[,2]

  #pca.hasta.harmonico.i[,1]
  #pca.hasta.harmonico.i[,2]

  #si es fitxer o matriu triar input:
  if (tipus.input ==1) {
    #si input ?s matriu M
    M.coord <-read.delim(file)
  }else
    #si input es matriu:
    M.coord <-M

  #almacenamiento: llenar vectores
    Fourier.matrix.results[1, 1]<-   nom.label #nombre
    Fourier.matrix.results[1, 2] <-  as.numeric(id.num) #numero
  #analisis PCA con todos los harmonicos filas y columnas (A, B, C y D):
    Fourier.matrix.results[1, 3] <-  pca$rotation[1,1] #coeficiente1 de la 1? componente - vector propio
    Fourier.matrix.results[1, 4] <-  pca$rotation[2,1] #coeficiente2 de la 1? componente
    Fourier.matrix.results[1, 5] <-  pca$rotation[3,1] #coeficiente3 de la 1? componente
    Fourier.matrix.results[1, 6] <-  pca$rotation[4,1] #coeficiente4 de la 1? componente
    Fourier.matrix.results[1, 7] <-  pca$rotation[1,2] #coeficiente1 de la 2? componente
    Fourier.matrix.results[1, 8] <-  pca$rotation[2,2] #coeficiente2 de la 2? componente
    Fourier.matrix.results[1, 9] <-  pca$rotation[3,2] #coeficiente3 de la 2? componente
    Fourier.matrix.results[1, 10] <- pca$rotation[4,2] #coeficiente4 de la 2? componente

  #4 columnas mas para el analisis PCA de harmonic0 1 al armonico num.harmonic:
    Fourier.matrix.results[1, 11] <-pca.hasta.harmonico.i$rotation[1,1] #PCA (1)
    Fourier.matrix.results[1, 12] <-pca.hasta.harmonico.i$rotation[2,1] #PCA (1)
    Fourier.matrix.results[1, 13] <-pca.hasta.harmonico.i$rotation[3,1] #PCA (1)
    Fourier.matrix.results[1, 14] <-pca.hasta.harmonico.i$rotation[4,1] #PCA (1)
    Fourier.matrix.results[1, 15] <-pca.hasta.harmonico.i$rotation[1,2] #PCA (1)
    Fourier.matrix.results[1, 16] <-pca.hasta.harmonico.i$rotation[2,2] #PCA (1)
    Fourier.matrix.results[1, 17] <-pca.hasta.harmonico.i$rotation[3,2] #PCA (1)
    Fourier.matrix.results[1, 18] <-pca.hasta.harmonico.i$rotation[4,2] #PCA (1)

  #Centro geométrico calculado con cluster-medoids (http://www.stat.berkeley.edu/~s133/Cluster2a.html)
  ##Fourier.matrix.results[1, 19] <-ef1$ao #ef1$ao 'old del EFD
  ##Fourier.matrix.results[1, 20] <-ef1$co #ef1$co 'old del EFD
    Fourier.matrix.results[1, 19] <-pam(data.frame(M.coord), 1)$medoids[1] #medoid X
    Fourier.matrix.results[1, 20] <-pam(data.frame(M.coord), 1)$medoids[2] #Medoid Y
  #distancia euclidea maxima entre coordenadas
    Fourier.matrix.results[1, 21] <-max(dist(M.coord)) #maxima distancia euclidea entre las coordenadas


  #almacenamiento total:
  #for (j in 1:14)
  #  image.results[id.num, j]<<-Fourier.matrix.results[1, j]
  #return(Fourier.matrix.results)
  #list(ao=ao,co=co,an=an,bn=bn,cn=cn,dn=dn)

  #returm coordinate matrix M
  "Print results PCA-EFD"
  return(Fourier.matrix.results)
  list(Fourier.matrix.results = Fourier.matrix.results)
}



#########################################################################################
#                        function halfter
#########################################################################################

halfter <- function (mylist)
{
  half.list <- mylist[-c(seq(1,nrow(mylist),by=2)), ] ##reduïm resolució a la meitad
  return(half.list)
}


#########################################################################################
#                        function halfter2
#########################################################################################
halfter2 <- function (mylist)
{
  half.list <- mylist[-c(seq(1,nrow(mylist),by=2)), ] ##reduïm resolució a la meitad
  return(half.list)
}

#########################################################################################
#                        function dataframer
#########################################################################################

dataframer <- function (mylist, n)     ## on 'n' és el nombre d'harmonics que volem agafar
{
  df <- data.frame(mylist$A[1:n],mylist$B[1:n],mylist$C[1:n],mylist$D[1:n])
  names(df) <- c('A','B','C','D')
  return(df)
}
#########################################################################################
#                        function unlist2
#########################################################################################

unlist2 <- function(nested.list){
  unnested.list1<-unlist(nested.list, recursive = FALSE)
  unnested.list0<-unlist(unnested.list1, recursive = FALSE)
  return (unnested.list0)
}
#########################################################################################
#                        function treshold
#########################################################################################

treshold<-function(myraster){
  ww <- Which(raster==0, cells=T)
  myraster[ww]<-1000
  w<- Which(r!=1000, cells=T)
  myraster[w]<-0
  return(myraster)
}

#########################################################################################
#                        function image.to.coords
#########################################################################################



###################################################################

#' image.to.coords
#'
#' @param filename name of the image file
#' @param foldername name of the folder containing the image files
#' @param  folder if want to extract coordinates of set of pictures set True, else or if you want just one picture set False
#' @return list with single image coordinates or list of coordinates of diferent images
#' @export
image.to.coords<-function(filename,foldername,folder=F)
{
  if (folder==T){
    filenames <- list.files(foldername, pattern = '*.tif', full.names = TRUE)
    rasters <- lapply(filenames, raster)
    contours <- lapply(rasters, rasterToContour, levels = 1)
    coords <- lapply(contours, coordinates)
    coords <- unlist2(coords)
    half.coords <- mapply(halfter, coords)

    return(half.coords)
  }else
    rasterim <- raster(filename)
  contour <- rasterToContour(rasterim, levels = 1)
  coords <- coordinates(contour)
  coords <- unlist(coords, recursive = FALSE)
  coords.mat <- as.matrix(coords[[1]])
  half.coords <- halfter2(coords.mat)
  return(half.coords)
}







####################################################
# DATA EXAMPLES
####################################################

###################################################
#  some data for the examples
####################################################
#see help at: http://portal.stats.ox.ac.uk/userdata/ruth/APTS2012/Rcourse10.pdf
numobs <- 100
x<- rnorm(numobs,106,90)
y<- rnorm(numobs,runif(1,min=0, max=1)*x,40)
scatterVisio <- data.frame(x,y)

save(scatterVisio, file="scatterVisio.rda")


#' Example of a simulated scatterplot.
#'
#' A dataset of 100 coordinates X, Y
#' scatterVisio.
#'
#' @format A data frame with 100 simulated coordinates:
#' \describe{
#'   \item{X}{coordinate X}
#'   \item{Y}{coordinate Y}}
"scatterVisio"
